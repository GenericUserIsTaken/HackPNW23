using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Building : MonoBehaviour
{
    public Building outputBuilding;
    public float timeToOutput = 1f;

    // set the product type (name string, names in Resource class)
    public string productType;

    // how long it takes to make product
    public float productionTime;//seconds
    public float produceTimer;
    
    List<Resource> heldResources;

    ShipmentManager shipmentManager;

    void Start()
    {
        heldResources = new List<Resource>();
        produceTimer = 0f;
        shipmentManager = GameObject.Find("/ShipmentManager").GetComponent<ShipmentManager>();
    }

    void Update()
    {
        // attempt to make product until it works then reset timer
        produceTimer += Time.deltaTime;
        if (produceTimer >= productionTime && HasEnoughResources())
        {
            Produce();
            produceTimer = 0f;
        }
    }

    // check how much of a type is held currently
    int GetResourceHeld(string type)
    {
        foreach (Resource res in heldResources)
        {
            if (res.type == type)
            {
                return res.ammount;
            }
        }
        return 0;
    }

    // recieve a resource from a shipment
    public void RecieveResource(Resource resource)
    {
        // check if resource already held to increase it's ammount
        foreach (Resource res in heldResources)
        {
            if (res.type == resource.type)
            {
                res.ammount += resource.ammount;
            }
            return;
        }
        // or add it to the list new
        heldResources.Add(new Resource(resource));
    }

    // recieve negative resource to take away (Very gud code lol)
    void UseResource(string type, int useAmmount)
    {
        RecieveResource(new Resource(type, -useAmmount));
    }

    // use resources, send product shipment
    void Produce()
    {
        // sell for money instead of shippping
        if (productType == "money")
        {
            int sellTotal = 0;
            foreach (Resource res in heldResources)
            {
                if (res.ammount > 0)
                {
                    UseResource(res.type, res.ammount);
                    sellTotal += Resource.SellPrice(res.type) * res.ammount;
                }
            }
            shipmentManager.GiveMoney(sellTotal);
        }
        // turn oil to power
        else if (productType == "power")
        {
            if (GetResourceHeld("rOil") >= 1)
            {
                UseResource("rOil",-1);
                SendShipment();
            }
            else if (GetResourceHeld("oil") >= 4)
            {
                UseResource("oil",-4);
                SendShipment();
            }
        }
        // any other recipe
        else
        {
            // use resources
            List<Resource> recipe = Resource.GetRecipe(productType);
            foreach (Resource res in recipe)
            {
                UseResource(res.type, res.ammount);
            }
            SendShipment();
        }
        
    }

    void SendShipment()
    {
        // send shipment
        shipmentManager.AddShipment(new Shipment(
            timeToOutput + Time.time, // game time plus time to complete path
            outputBuilding, // destination building
            new Resource(productType, 1) // send one product
        ));
    }

    // check if holding enough resources
    bool HasEnoughResources()
    {
        List<Resource> recipe = Resource.GetRecipe(productType);
        // if it's selling
        if (productType == "money")
        {
            // if at least one thing to sell
            foreach (Resource res in heldResources)
            {
                if (res.ammount > 0)
                {
                    return true;
                }
            }
            return false;
        }
        // handle power recipe separately for duel options
        else if (productType == "power")
        {
            // if it has enough oil or rOil
            if (GetResourceHeld("oil") >= 4 || GetResourceHeld("rOil") >= 1)
            {
                return true;
            }
            return false;
        }
        // anything else recipe
        else
        {
            foreach (Resource res in recipe)
            {
                // if we doesn't have enough
                if (GetResourceHeld(res.type) < res.ammount)
                {
                    return false;
                }
            }
            return true;
        }
    }

}
