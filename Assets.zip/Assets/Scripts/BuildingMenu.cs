using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildingMenu : MonoBehaviour
{

    public GameObject buildingGrid;
    BuildingSystem bs;

    public GameObject powerPlant, plasticFactory, bottleFactory,
        carFactory, sawmill, oilPump, furnitureFactory, oilRefinery;

    void Start()
    {
        bs = buildingGrid.GetComponent<BuildingSystem>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyUp(KeyCode.Tab))
        {
            // mousepos from center of screen
            Vector3 centerScreen = new Vector3(Screen.width/2f, Screen.height/2f, 0f);
            Vector3 mousePos = Input.mousePosition - centerScreen;

            float angle = Mathf.Atan2(mousePos.y, mousePos.x) * Mathf.Rad2Deg;

            int index = (int)Mathf.Ceil(angle / 45f) + 3;
            if (index < 0) {
                index = 0;
            }

            // use index in array of gamethings for building?
            //bs.prefab1 = 
            switch (index)
            {
                case 0:
                    bs.prefab1 = powerPlant;
                    break;
                case 1:
                    bs.prefab1 = plasticFactory;
                    break;
                case 2:
                    bs.prefab1 = bottleFactory;
                    break;
                case 3:
                    bs.prefab1 = carFactory;
                    break;
                case 4:
                    bs.prefab1 = sawmill;
                    break;
                case 5:
                    bs.prefab1 = oilPump;
                    break;
                case 6:
                    bs.prefab1 = furnitureFactory;
                    break;
                case 7:
                    bs.prefab1 = oilRefinery;
                    break;
                default:
                    bs.prefab1 = null;
                    break;
            }
        }
        if (Input.GetKey(KeyCode.Tab))
        {
            // on screen
            transform.localPosition = new Vector3(0f, 0f, 0f);
        }
        else
        {
            // off screen
            transform.localPosition = new Vector3(0f, -500f, 0f);
        }
    }
}
