using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;


public class BuildingSystem : MonoBehaviour
{
    public static BuildingSystem current;

    public GridLayout gridLayout;
    private Grid grid;
    [SerializeField] private Tilemap MainTilemap;
    [SerializeField] private TileBase whiteTile;

    public GameObject prefab1;
    public GameObject prefab2;

    private PlaceableObject objectToPlace;

    #region Unity methods
    // Start is called before the first frame update
    void Awake()
    {
        current = this;
        grid = gridLayout.gameObject.GetComponent<Grid>();
    }

    // Update is called once per frame
    void Update()
    {   
        if (Input.GetKeyDown(KeyCode.Q))
        {
            InitializeWithObject(prefab1); //warning, shit ass fixes aren't implemented for initial object creation
        }else if (Input.GetKeyDown(KeyCode.E))
        {
            InitializeWithObject(prefab2);
        }
        //quick test funciton for mouse, results: all mouse functions fully operational
        /*
        else if (Input.GetKeyDown(KeyCode.T))
        {

            Vector3 mousePoint = BuildingSystem.GetMouseWorldPosition();
            Debug.DrawLine(mousePoint, mousePoint + new Vector3(0, 5, 0), Color.cyan, 8f);
            Vector3 actual = BuildingSystem.current.SnapCoordinateToGrid(mousePoint);
            Debug.DrawLine(actual, actual + new Vector3(0, 5, 0), Color.black, 8f);
            Vector3 testPoint = BuildingSystem.current.SnapCoordinateToGridCorner(mousePoint);
            Debug.DrawLine(testPoint, testPoint + new Vector3(0, 5, 0), Color.blue, 8f);
        }
        */
        if (!objectToPlace)
        {
            return;
        }

        if (Input.GetKeyDown(KeyCode.R))
        {
            if (CanBePlaced(objectToPlace))
            {
                objectToPlace.Place();
                Vector3Int start = gridLayout.WorldToCell(objectToPlace.GetStartPosition());

                //start quick fix
                PlaceableObject po = objectToPlace.GetComponent<PlaceableObject>();
                TakeArea(start, objectToPlace.Size, po.quickAreaFixX, po.quickAreaFixY);
                //end quick fix

                //old code
                //TakeArea(start, objectToPlace.Size);

                objectToPlace = null;
            }
            else
            {
                Destroy(objectToPlace.gameObject);
            }
            
        }
        
    }
# endregion

    #region Utils
    public static Vector3 GetMouseWorldPosition()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out RaycastHit raycastHit))
        {
            return raycastHit.point;
        }
        else
        {
            return Vector3.zero;
        }
    }

    //this method takes in a position and returns the nearest CENTER of a grid
    public Vector3 SnapCoordinateToGrid(Vector3 position)
    {
        Vector3Int cellPos = gridLayout.WorldToCell(position);
        position = grid.GetCellCenterWorld(cellPos);
        //see where position is snapped to (commented results above)
        //Debug.DrawLine(position, position + new Vector3(0, 5, 0), Color.red, 8f);
        return position;
    }

    //this method takes in a position and returns the nearest Bottom Left of a grid
    public Vector3 SnapCoordinateToGridCorner(Vector3 position)
    {
        position = SnapCoordinateToGrid(position);
        position = position + new Vector3(-8,0,-8);
        Debug.DrawLine(position, position + new Vector3(0, 5, 0), Color.red, 8f);
        return position;
    }

    private static TileBase[] GetTilesBlock(BoundsInt area, Tilemap tilemap)
    {
        TileBase[] array = new TileBase[area.size.x * area.size.y * area.size.z];
        //cool counter TODO praise counter
        int counter = 0;

        foreach (var v in area.allPositionsWithin){
            Vector3Int pos = new Vector3Int(v.x,v.y,0);
            array[counter] = tilemap.GetTile(pos);
            counter++; 
        }
        return array;
    }

    #endregion
    #region Building Placement
    public void InitializeWithObject(GameObject prefab)
    {
        if (objectToPlace)
        {
            return;
        }
        //this is where we should take mouse input to spawn object to mouse
        //Vector3 position = SnapCoordinateToGrid(Vector3.zero);
        PlaceableObject po = prefab.GetComponent<PlaceableObject>();
        Vector3 position;
        if (po && po.snapToPoint)
        {
            Vector3 getSnapPointCornerPosition = SnapCoordinateToGridCorner(BuildingSystem.GetMouseWorldPosition());
            position = getSnapPointCornerPosition + (transform.position - po.snapToPoint.position);
        }
        else
        {
            position = SnapCoordinateToGrid(BuildingSystem.GetMouseWorldPosition());
        }
        

        //Vector3 getSnapPointCornerPosition = BuildingSystem.current.SnapCoordinateToGridCorner(pos);
        //transform.position = getSnapPointCornerPosition + (transform.position - po.snapToPoint.position);


        GameObject obj = Instantiate(prefab, position, Quaternion.identity);
        objectToPlace = obj.GetComponent<PlaceableObject>();
        obj.AddComponent<ObjectDrag>();
    }

    private bool CanBePlaced(PlaceableObject po)
    {
        BoundsInt area = new BoundsInt();
        area.position = gridLayout.WorldToCell(objectToPlace.GetStartPosition());
        area.size = po.Size;

        TileBase[] baseArray = GetTilesBlock(area, MainTilemap);

        foreach(var b in baseArray)
        {
            if(b == whiteTile)
            {
                return false;
            }
        }
        return true;
    }

    public void TakeArea(Vector3Int start, Vector3Int size)
    {
        TakeArea(start,size,0,0);
    }

    public void TakeArea(Vector3Int start, Vector3Int size, int quickfixX, int quickfixY)
    {
        MainTilemap.BoxFill(start, whiteTile, start.x, start.y,
                             start.x + size.x + quickfixX, start.y + size.y + quickfixY);
    }
    #endregion
}
