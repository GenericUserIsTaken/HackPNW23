using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cameramovement : MonoBehaviour
{
    public GameObject target;
    float moveSpeed, rotateSpeed;
    public float sensitivity;

    float distanceToAnchor;

    void Start()
    {
        moveSpeed = 40f;
        rotateSpeed = 100f;

        distanceToAnchor = 10f;
    }

    void Update()
    {
        // get the recent input
        Vector2 movement = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));

        // apply movement respective of the camera rotation
        if (movement.x != 0f)
        {
            // left right movement
            transform.position += transform.right * movement.x * moveSpeed * Time.deltaTime;
        }
        if (movement.y != 0f)
        {
            // forward backwards movement
            transform.position += transform.forward * movement.y * moveSpeed * Time.deltaTime;
        }

        // update the rotation anchor position
        target.transform.position = transform.forward * distanceToAnchor + transform.position;

        // rotate camera mode
        if (Input.GetKey(KeyCode.Space))
        {
            // take away cursor while rotating
            Cursor.lockState = CursorLockMode.Locked;

            // get mouse change input (dx,dy)
            Vector2 mouseChange = sensitivity * new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));

            // rotate around anchor point
            transform.RotateAround(target.transform.position, Vector3.up, mouseChange.x * rotateSpeed * Time.deltaTime);
        }
        else
        {
            // give back access to cursor
            Cursor.lockState = CursorLockMode.None;
        }
    }
}