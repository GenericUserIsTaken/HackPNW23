using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectDrag : MonoBehaviour
{
    private Vector3 offset;
    public PlaceableObject po;
    public bool shouldSnapToCorner = false;

    public void Start()
    {
        po = this.gameObject.GetComponent<PlaceableObject>();
        if (po.snapToPoint)
        {
            shouldSnapToCorner = true;
        }
    }

    private void OnMouseDown()
    {
        if (!shouldSnapToCorner){ 
            offset = transform.position - BuildingSystem.GetMouseWorldPosition();
        }
        else
        {
            //maybe normalize position to world space
            Debug.DrawLine(po.snapToPoint.position, po.snapToPoint.position + new Vector3(0, 5, 0), Color.blue, 8f);
            offset = po.snapToPoint.position - BuildingSystem.GetMouseWorldPosition();
        }
    }

    private void OnMouseDrag()
    {
        Vector3 pos = BuildingSystem.GetMouseWorldPosition() + offset;
        if (!shouldSnapToCorner)
        {
            transform.position = BuildingSystem.current.SnapCoordinateToGrid(pos);
        }
        else
        {
            Vector3 getSnapPointCornerPosition = BuildingSystem.current.SnapCoordinateToGridCorner(pos);
            //transform.position = getSnapPointCornerPosition + (transform.position - po.snapToPoint.position);//po.snapToPoint.localPosition
            transform.position = getSnapPointCornerPosition + (transform.position - po.snapToPoint.position);
        }
    }
}
