using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaceableObject : MonoBehaviour
{
    public bool Placed { get; private set; }
    public Vector3Int Size { get; private set; }
    private Vector3[] Vertices;
    public Transform snapToPoint;
    public int quickAreaFixX;
    public int quickAreaFixY;

    private void Setup()
    {
        //get target location and set it as the snapping point
        snapToPoint = this.transform.Find("Target");
        //get ground
        Transform groundT = this.transform.Find("Ground");
        if (!groundT)
        {
            Debug.LogWarning("AUTOMATIC SETUP FAILED FOR " + this.transform.gameObject.name, this.transform);
            return;
        }
        FitColliderToChildren(transform.gameObject);
        /*
        GameObject ground = groundT.gameObject;
        //get its box collider size
        BoxCollider bc = ground.AddComponent(typeof(BoxCollider)) as BoxCollider;
        //hide ground
        ground.GetComponent<MeshRenderer>().enabled = false;
        //make new box collider
        BoxCollider bc2 = transform.gameObject.AddComponent(typeof(BoxCollider)) as BoxCollider;
        //copy over size and center scaled to world space
        bc2.center = bc.center;
        bc2.size = bc.size;
        */

        //delete all the annoying cameras and lights
        foreach (Transform part in this.transform)
        {
            GameObject go = part.gameObject;
            if(go.name.Contains("Camera") || go.name.Contains("Light"))
            {
                Destroy(go);
            }
            
        }

    }

    private void FitColliderToChildren(GameObject parentObject)
    {
        BoxCollider bc = parentObject.GetComponent<BoxCollider>();
        if (bc == null) { bc = parentObject.AddComponent<BoxCollider>(); }
        Bounds bounds = new Bounds(Vector3.zero, Vector3.zero);
        bool hasBounds = false;
        Renderer[] renderers = parentObject.GetComponentsInChildren<Renderer>();
        foreach (Renderer render in renderers)
        {
            if (hasBounds)
            {
                bounds.Encapsulate(render.bounds);
            }
            else
            {
                bounds = render.bounds;
                hasBounds = true;
            }
        }
        if (hasBounds)
        {
            bc.center = bounds.center - parentObject.transform.position;
            bc.size = bounds.size;
        }
        else
        {
            bc.size = bc.center = Vector3.zero;
            bc.size = Vector3.zero;
        }
    }

private void GetColliderVertexPositionsLocal()
    {
        BoxCollider b = gameObject.GetComponentInChildren<BoxCollider>();
        Vertices = new Vector3[4];
        Vertices[0] = b.center + new Vector3(-b.size.x,-b.size.y,-b.size.z) * 0.5f;
        Vertices[1] = b.center + new Vector3(b.size.x, -b.size.y, -b.size.z) * 0.5f;
        Vertices[2] = b.center + new Vector3(b.size.x, -b.size.y, b.size.z) * 0.5f;
        Vertices[3] = b.center + new Vector3(-b.size.x, -b.size.y, b.size.z) * 0.5f;
    }

    private void CalculateSizeInCells() //imagine making a method that somehow can't count to 4 and instead skips to 9
    {
        Vector3Int[] vertices = new Vector3Int[Vertices.Length];

        for(int i = 0; i < vertices.Length; i++)
        {
            Vector3 worldPos = transform.TransformPoint(Vertices[i]);
            vertices[i] = BuildingSystem.current.gridLayout.WorldToCell(worldPos);
        }

        Size = new Vector3Int(Math.Abs((vertices[0] - vertices[1]).x), //suprisngly isn't causing the size upscaling rounding issue ;-;
            Math.Abs((vertices[0] - vertices[3]).y), 1);                // in other words dont slap mathf.round and expect it to work
    }

    //should have just changed this to be corner but whatever bad math go brrrt
    public Vector3 GetStartPosition()
    {
        //Debug.DrawLine(transform.TransformPoint(Vertices[0]), transform.TransformPoint(Vertices[0]) + new Vector3(0, 5, 0), Color.red, 8f);
        return transform.TransformPoint(Vertices[0]);
    }

    // Start is called before the first frame update
    void Start()
    {
        Setup();
        GetColliderVertexPositionsLocal();
        CalculateSizeInCells();
    }

    public virtual void Place()
    {
        ObjectDrag drag = gameObject.GetComponent<ObjectDrag>();
        Destroy(drag);

        Placed = true;

        //finish placing object if you need to add stuff
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
