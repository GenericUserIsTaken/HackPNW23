using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInfo : MonoBehaviour
{
    public float money;

    public void GiveMoney(int money)
    {
        money += money;
    }

    public void SpendMoney(int cost)
    {
        money -= cost;
    }
}
