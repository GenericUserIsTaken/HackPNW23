using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Resource
{
    public string type;
    public int ammount;

    public Resource(string type, int ammount)
    {
        this.type = IsValidType(type)?type:"lumber";
        this.ammount = ammount;
    }
    public Resource(Resource res)
    {
        this.type = res.type;
        this.ammount = res.ammount;
    }

    // get the resource requirements for a product
    public static List<Resource> GetRecipe(string product)
    {
        if (IsValidType(product))
        {
            return recipes[product];
        }
        return new List<Resource>();
    }

    // double check if a type name is supported
    public static bool IsValidType(string type)
    {
        return typeNames.Contains(type);
    }

    // valid type names
    public static List<string> typeNames = new List<string>()
    {
        "lumber",
        "oil",
        "rOil",
        "power",
        "planks",
        "furniture",
        "plastics",
        "bottles",
        "cars",
        "chassis",
        "money"
    };

    // resource type -> list of resources (type, ammount required)
    static Dictionary<string, List<Resource>> recipes = new Dictionary<string, List<Resource>>()
    {
        {"lumber", new List<Resource>(){
        }},
        {"oil", new List<Resource>(){
        }},
        {"chassis", new List<Resource>(){
        }},
        {"planks", new List<Resource>(){
            new Resource("lumber", 4)
        }},
        {"furniture", new List<Resource>(){
            new Resource("power", 2),
            new Resource("planks", 4)
        }},
        {"rOil", new List<Resource>(){
            new Resource("oil", 1)
        }},
        {"plastics", new List<Resource>(){
            new Resource("oil", 16),
            new Resource("power", 4)
        }},
        {"bottles", new List<Resource>(){
            new Resource("plastics", 8),
            new Resource("power", 8)
        }},
        {"cars", new List<Resource>(){
            new Resource("chassis", 4),
            new Resource("power", 16),
            new Resource("plastics", 16)
        }}
    };

    public static int SellPrice(string type)
    {
        return sellPrices.ContainsKey(type)?sellPrices[type]:0;
    }

    // resource to money ammount
    static Dictionary<string, int> sellPrices = new Dictionary<string, int>()
    {
        {"lumber",0},
        {"oil",0},
        {"rOil",0},
        {"chassis",0},
        {"planks",1},
        {"furniture",20},
        {"plastics",10},
        {"bottles",1000},
        {"cars",10000}
    };
}