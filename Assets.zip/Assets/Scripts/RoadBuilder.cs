using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Splines;

public class RoadBuilder : MonoBehaviour
{
    public GameObject road;
    public Vector3 lastPos;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.G) && Input.GetMouseButtonDown(0))
        {
            Vector3 location = BuildingSystem.GetMouseWorldPosition();
            if(lastPos == null)
            {
                lastPos = location;
            }
            else
            {
                CreateRec(lastPos, location);
                lastPos = location;
            }
        }
    }

    private void CreateRec(Vector3 start, Vector3 end)
    {
        GameObject quad = Instantiate(road);
        Vector3[] verts = {start, end};
        quad.transform.localPosition = CenterOfVectors(verts) +new Vector3(0f,0.2f,0f);
        float distance = Vector3.Distance(end,start);
        //quad.transform.localScale = new Vector3(Mathf.Abs(annoying.x), Mathf.Abs(annoying.y), Mathf.Abs(annoying.z));
        quad.transform.localScale = new Vector3(Mathf.Abs(distance), 20f, 20f);
        quad.transform.eulerAngles = new Vector3(90f,Vector3.Angle(start, CenterOfVectors(verts)), 0f);

    }


    public Vector3 CenterOfVectors(Vector3[] vectors)
    {
        Vector3 sum = Vector3.zero;
        if (vectors == null || vectors.Length == 0)
        {
            return sum;
        }

        foreach (Vector3 vec in vectors)
        {
            sum += vec;
        }
        return sum / vectors.Length;
    }
}
