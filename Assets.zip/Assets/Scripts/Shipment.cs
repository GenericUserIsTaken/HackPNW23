using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shipment
{
    public float finishTime;
    Resource resource;
    Building destination;

    // send the resource to the destination building
    // called in shipmentmanager
    public void SendResource()
    {
        destination.RecieveResource(resource);
    }

    // setup the shipment
    public Shipment(float finishTime, Building destination, Resource resource)
    {
        this.finishTime = finishTime;
        this.destination = destination;
        this.resource = resource;
    }
}
