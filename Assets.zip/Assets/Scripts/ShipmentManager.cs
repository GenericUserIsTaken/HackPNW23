using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipmentManager : MonoBehaviour
{
    PlayerInfo playerInfo;

    List<Shipment> shipments;

    void Start()
    {
        shipments = new List<Shipment>();
    }

    // add a shipment to the list
    public void AddShipment(Shipment shipment)
    {
        shipments.Add(shipment);
    }

    public void GiveMoney(int money)
    {
        playerInfo.GiveMoney(money);
    }

    void Update()
    {
        float currentTime = Time.time;
        foreach(Shipment shipment in shipments)
        {
            // if current time has passed finish time
            if (shipment.finishTime < currentTime)
            {
                // complete the shipment
                shipment.SendResource();
            }
        }
    }
}
